# Apex legends review

## gameplay
Apex legends is een unieke game van de battle royale genre. zelf ben ik geen fan van deze genre maar de unieke gameplay maakt het spel erg plezierig om te spelen. de game wordt gespeeld in teams van 3.

## design en visuals
Apex legends doet het goed als het gaat om visuals en character design. Apex legends slaagt erin om characters memorabel, en uniek te maken. elke character beschikt over zijn of haar eigen ability wat de abilties van andere spelers sterker kunnen maken. in elke character zit enige vorm van persoonlijkheid. grafisch gezien is de game kleurrijk, en zijn de maps ook erg uniek. elke map speelt zich af op een andere planeet, wat het idee van unieke maps erg logisch maakt, en artistieke mogelijkheden bied. 

## conclusie
Apex legends vereist tactisch inzicht, en goede communicatie met teamgenoten. het is een solide game waar visueel erg veel levendigheid in zit. de variatie van characters, hun ablities, en maps maakt Apex legends een plezierig spel wat niet snel als herhalend gezien kan worden.

![apex legends](apex.jpg) 